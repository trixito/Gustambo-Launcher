#!/usr/bin/env python3
"""Aplica Discord Rich Presence al repo (se ejecuta desde la raiz del repo).
Uso: python3 apply_discord_rpc.py <carpeta_del_paquete>
Es idempotente: si un cambio ya esta aplicado, lo omite.
No escribe nada hasta comprobar que todos los cambios encajan."""
import os
import shutil
import sys

PKG = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
BASE = "ZalithLauncher/src/main/java/com/movtery/zalithlauncher"

pending = {}   # ruta -> contenido nuevo
errors = []


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def need(path):
    if not os.path.exists(path):
        errors.append(f"No existe {path}")
        return None
    return read(path)


def edit(path, fn):
    s = need(path)
    if s is None:
        return
    try:
        new = fn(s)
    except AssertionError as e:
        errors.append(f"{path}: {e}")
        return
    if new != s:
        pending[path] = new


def once(s, old, new, label):
    assert s.count(old) == 1, f"no encontre el punto de insercion ({label})"
    return s.replace(old, new, 1)


# 1) settings.gradle.kts -> JitPack
def f_settings(s):
    if "jitpack.io" in s:
        return s
    i = s.index("dependencyResolutionManagement")
    j = s.index("mavenCentral()", i)
    return s[:j] + 'mavenCentral()\n        maven("https://jitpack.io")' + s[j + len("mavenCentral()"):]
edit("settings.gradle.kts", f_settings)


# 2) build.gradle.kts -> dependencia
def f_build(s):
    if "dead8309:KizzyRPC" in s:
        return s
    old = "    implementation(libs.fishnet)\n"
    return once(s, old, old + '    implementation("com.github.dead8309:KizzyRPC:1.0.71")\n', "fishnet")
edit("ZalithLauncher/build.gradle.kts", f_build)


# 3) AndroidManifest.xml -> activity de login
def f_manifest(s):
    if "DiscordLoginActivity" in s:
        return s
    anchor = '        <activity android:name=".ui.activities.FatalErrorActivity"'
    block = ('        <activity\n'
             '            android:name=".ui.activities.DiscordLoginActivity"\n'
             '            android:exported="false"\n'
             '            android:configChanges="keyboardHidden|orientation|screenSize" />\n')
    return once(s, anchor, block + anchor, "FatalErrorActivity")
edit("ZalithLauncher/src/main/AndroidManifest.xml", f_manifest)


# 4) GameService.kt -> iniciar/detener el presence
def f_service(s):
    if "DiscordRpcController" in s:
        return s
    s = once(s, "import com.movtery.zalithlauncher.R\n",
             "import com.movtery.zalithlauncher.R\nimport com.movtery.zalithlauncher.game.discord.DiscordRpcController\n",
             "import R")
    old = "        super.onCreate()\n        startForegroundNotification()\n    }\n"
    new = ("        super.onCreate()\n        startForegroundNotification()\n"
           "        //Gustambo: Discord Rich Presence (solo si el jugador lo activo)\n"
           "        DiscordRpcController.start(applicationContext)\n    }\n\n"
           "    override fun onDestroy() {\n        DiscordRpcController.stop()\n        super.onDestroy()\n    }\n")
    return once(s, old, new, "onCreate")
edit(f"{BASE}/game/launch/GameService.kt", f_service)


# 5) strings.xml
def f_strings(s):
    if "settings_game_discord_rpc_title" in s:
        return s
    new = (
        '\n    <!-- Gustambo: Discord Rich Presence -->\n'
        '    <string name="settings_game_discord_rpc_title">Discord Rich Presence</string>\n'
        '    <string name="settings_game_discord_rpc_summary">Show on your Discord profile that you are playing Trixsafio. Not officially supported by Discord, so use it at your own risk</string>\n'
        '    <string name="settings_game_discord_rpc_login_title">Sign in to Discord</string>\n'
        "    <string name=\"settings_game_discord_rpc_login_summary\">Sign in through Discord\\'s website. The session is stored encrypted on this device only</string>\n"
        '    <string name="settings_game_discord_rpc_logout_title">Sign out of Discord</string>\n'
        '    <string name="settings_game_discord_rpc_logout_summary">Remove the saved session from this device</string>\n')
    return once(s, "</resources>", new + "</resources>", "</resources>")
edit("ZalithLauncher/src/main/res/values/strings.xml", f_strings)


# 6) GameSettingsScreen.kt -> botones en Ajustes > Juego
UI_BLOCK = '''
            //Gustambo: Discord Rich Presence
            AnimatedItem { ctx ->
                SettingsCardColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animated(ctx)
                ) {
                    val context = LocalContext.current
                    var enabled by remember { mutableStateOf(DiscordRpcStore.isEnabled(context)) }
                    var loggedIn by remember { mutableStateOf(DiscordRpcStore.hasToken(context)) }

                    val loginLauncher = rememberLauncherForActivityResult(
                        ActivityResultContracts.StartActivityForResult()
                    ) {
                        loggedIn = DiscordRpcStore.hasToken(context)
                        if (loggedIn) {
                            DiscordRpcStore.setEnabled(context, true)
                            enabled = true
                        }
                    }

                    SettingsCard(
                        modifier = Modifier.fillMaxWidth(),
                        position = CardPosition.Top,
                        title = stringResource(R.string.settings_game_discord_rpc_title),
                        summary = stringResource(R.string.settings_game_discord_rpc_summary),
                        onClick = {},
                        trailingIcon = {
                            Switch(
                                checked = enabled && loggedIn,
                                onCheckedChange = { on ->
                                    if (on && !loggedIn) {
                                        loginLauncher.launch(Intent(context, DiscordLoginActivity::class.java))
                                    } else {
                                        enabled = on
                                        DiscordRpcStore.setEnabled(context, on)
                                    }
                                }
                            )
                        }
                    )

                    SettingsCard(
                        modifier = Modifier.fillMaxWidth(),
                        position = CardPosition.Bottom,
                        title = stringResource(
                            if (loggedIn) R.string.settings_game_discord_rpc_logout_title
                            else R.string.settings_game_discord_rpc_login_title
                        ),
                        summary = stringResource(
                            if (loggedIn) R.string.settings_game_discord_rpc_logout_summary
                            else R.string.settings_game_discord_rpc_login_summary
                        ),
                        onClick = {
                            if (loggedIn) {
                                DiscordRpcStore.clearToken(context)
                                DiscordRpcStore.setEnabled(context, false)
                                loggedIn = false
                                enabled = false
                            } else {
                                loginLauncher.launch(Intent(context, DiscordLoginActivity::class.java))
                            }
                        },
                        trailingIcon = {}
                    )
                }
            }
'''
UI_IMPORTS = [
    "import android.content.Intent",
    "import androidx.activity.compose.rememberLauncherForActivityResult",
    "import androidx.activity.result.contract.ActivityResultContracts",
    "import androidx.compose.material3.Switch",
    "import androidx.compose.runtime.getValue",
    "import androidx.compose.runtime.mutableStateOf",
    "import androidx.compose.runtime.setValue",
    "import com.movtery.zalithlauncher.game.discord.DiscordRpcStore",
    "import com.movtery.zalithlauncher.ui.activities.DiscordLoginActivity",
]


def f_gss(s):
    if "DiscordRpcStore" in s:
        return s
    anchor = "import androidx.compose.foundation.layout.Arrangement\n"
    missing = [i for i in UI_IMPORTS if (i + "\n") not in s]
    s = once(s, anchor, "\n".join(missing) + "\n" + anchor, "imports")
    tail = "        }\n    }\n}\n\n\n@Composable\nprivate fun NativePluginSummaryLayout"
    return once(s, tail, UI_BLOCK + tail, "fin de GameSettingsScreen")
edit(f"{BASE}/ui/screens/content/settings/GameSettingsScreen.kt", f_gss)


# 7) proguard
def f_proguard(s):
    if "com.my.kizzyrpc" in s:
        return s
    return s.rstrip("\n") + "\n\n-keep class com.my.kizzyrpc.** { *; }\n"
pg = "ZalithLauncher/proguard-rules.pro"
if os.path.exists(pg):
    edit(pg, f_proguard)
else:
    pending[pg] = "-keep class com.my.kizzyrpc.** { *; }\n"


# 8) archivos nuevos
new_root = os.path.join(PKG, "new")
copies = []
for root, _, files in os.walk(new_root):
    for name in files:
        src = os.path.join(root, name)
        dst = os.path.relpath(src, new_root)
        copies.append((src, dst))

if errors:
    print("NO SE APLICO NADA. Problemas encontrados:")
    for e in errors:
        print(" -", e)
    sys.exit(1)

for path, content in pending.items():
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(content)
    print("modificado:", path)
for src, dst in copies:
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copyfile(src, dst)
    print("nuevo/actualizado:", dst)
print("Listo.")
